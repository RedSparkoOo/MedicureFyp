package com.example.docportal.Patient;

import static com.example.docportal.R.layout.spinner_item;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.docportal.Broadcasts;
import com.example.docportal.FirestoreHandler;
import com.example.docportal.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class medicineReminder extends AppCompatActivity {
    ImageView back_to_health_tracker;
    Spinner medicine_type;
    EditText medicine_name;
    EditText medicine_time;
    TextView Sunday;
    TextView Monday;
    TextView Tuesday;
    TextView Wednesday;
    TextView Thursday;
    TextView Friday;
    TextView Saturday;
    CheckBox every_day;
    Button medicine_to_recycler;
    String TimeZone;
    String TIME;
    int hour;
    int minute;
    String[] medicine_types = {"", "Capsule", "Adhesive", "Syrup", "Tablet"};
    ArrayList<String> medicinesNames;
    ArrayList<String> medicinesDuration;
    ArrayList<String> medicinesTime;
    ArrayList<String> medicineType;
    int Sunday_count = 0;
    int Monday_count = 0;
    int Tuesday_count = 0;
    int Wednesday_count = 0;
    int Thursday_count = 0;
    int Friday_count = 0;
    int Saturday_count = 0;
    String day1_Sunday;
    String day2_Monday;
    String day3_Tuesday;
    String day4_Wednesday;
    String day5_Thursday;
    String day6_Friday;
    String day7_Saturday;
    String med_types;
    String medicine_name_entered;
    String duration = "";
    FirestoreHandler firestoreHandler = new FirestoreHandler();
    private Calendar calendar;
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_reminder);


        back_to_health_tracker = findViewById(R.id.back_to_health_tracker);
        medicine_to_recycler = findViewById(R.id.medicine_to_recycler);
        medicine_name = findViewById(R.id.medicine_name);
        Sunday = findViewById(R.id.Sunday);
        Monday = findViewById(R.id.Monday);
        Tuesday = findViewById(R.id.Tuesday);
        Wednesday = findViewById(R.id.Wednesday);
        Thursday = findViewById(R.id.Thursday);
        Friday = findViewById(R.id.Friday);
        Saturday = findViewById(R.id.Saturday);
        every_day = findViewById(R.id.every_day);
        medicine_time = findViewById(R.id.medicine_time);
        medicine_type = findViewById(R.id.medicine_type);


        medicinesNames = new ArrayList<>();
        medicineType = new ArrayList<>();
        medicinesTime = new ArrayList<>();
        medicinesDuration = new ArrayList<>();


        ArrayAdapter arrayAdapterTypes = new ArrayAdapter(this, spinner_item, medicine_types);
        arrayAdapterTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        medicine_type.setAdapter(arrayAdapterTypes);


        medicine_to_recycler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                medicine_name_entered = medicine_name.getText().toString();
                med_types = medicine_type.getSelectedItem().toString();
                checkDuration();

                RemindertoFirebase(medicine_name_entered, med_types, TIME, duration);


            }
        });


        SendMedicines();
        showTimePicker();


        back_to_health_tracker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    private void RemindertoFirebase(String medic_name, String medic_type, String medic_time, String medic_duration) {
        firestoreHandler.getFirestoreInstance().clearPersistence();
        DocumentReference reference = firestoreHandler.getFirestoreInstance().collection("Medicine Reminder").document();
        reference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                Map<Object, String> reminder = new HashMap<>();
                reminder.put("Medicine Name", medic_name);
                reminder.put("Medicine Type", medic_type);
                reminder.put("Medicine Time", medic_time);
                reminder.put("Medicine Duration", medic_duration);
                reminder.put("Patient ID", firestoreHandler.getCurrentUser());
                reference.set(reminder);
                Intent intent = new Intent(medicineReminder.this, ReminderStored.class);
                startActivity(intent);
            }
        });

    }

    private void checkDuration() {

        if (day1_Sunday != null) {
            medicinesDuration.add(day1_Sunday);
        }

        if (day2_Monday != null) {
            medicinesDuration.add(day2_Monday);
        }

        if (day3_Tuesday != null) {
            medicinesDuration.add(day3_Tuesday);
        }

        if (day4_Wednesday != null) {
            medicinesDuration.add(day4_Wednesday);
        }

        if (day5_Thursday != null) {
            medicinesDuration.add(day5_Thursday);
        }

        if (day6_Friday != null) {
            medicinesDuration.add(day6_Friday);
        }

        if (day7_Saturday != null) {
            medicinesDuration.add(day7_Saturday);
        }

        for (String value : medicinesDuration) {
            duration += value + " ";

        }


    }

    private void SendMedicines() {

        //--------------------------------ALL DAYS------------------------------------------//

        showTimePicker();
        every_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (every_day.isChecked()) {

                    Sunday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Sunday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Monday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Monday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Tuesday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Tuesday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Wednesday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Wednesday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Thursday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Thursday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Friday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Friday.setTextColor(Color.parseColor("#FFFFFFFF"));


                    Saturday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Saturday.setTextColor(Color.parseColor("#FFFFFFFF"));

                    day1_Sunday = "Sunday";
                    day2_Monday = "Monday";
                    day3_Tuesday = "Tuesday";
                    day4_Wednesday = "Wednesday";
                    day5_Thursday = "Thursday";
                    day6_Friday = "Friday";
                    day7_Saturday = "Saturday";

                    medicinesDuration.add(day1_Sunday);
                    medicinesDuration.add(day2_Monday);
                    medicinesDuration.add(day4_Wednesday);
                    medicinesDuration.add(day3_Tuesday);
                    medicinesDuration.add(day5_Thursday);
                    medicinesDuration.add(day6_Friday);
                    medicinesDuration.add(day7_Saturday);


                }

                if (!every_day.isChecked()) {

                    Sunday.setBackground(null);
                    Sunday.setTextColor(Color.parseColor("#434242"));


                    Monday.setBackground(null);
                    Monday.setTextColor(Color.parseColor("#434242"));


                    Tuesday.setBackground(null);
                    Tuesday.setTextColor(Color.parseColor("#434242"));

                    Wednesday.setBackground(null);
                    Wednesday.setTextColor(Color.parseColor("#434242"));

                    Thursday.setBackground(null);
                    Thursday.setTextColor(Color.parseColor("#434242"));

                    Friday.setBackground(null);
                    Friday.setTextColor(Color.parseColor("#434242"));

                    Saturday.setBackground(null);
                    Saturday.setTextColor(Color.parseColor("#434242"));

                    day1_Sunday = null;
                    day2_Monday = null;
                    day3_Tuesday = null;
                    day4_Wednesday = null;
                    day5_Thursday = null;
                    day6_Friday = null;
                    day7_Saturday = null;

                    medicinesDuration.clear();
                }

            }
        });

        Sunday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Sunday_count == 0) {
                    Sunday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Sunday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day1_Sunday = "Sunday";
                    Sunday_count = 1;

                } else if (Sunday_count == 1) {
                    Sunday.setBackground(null);
                    Sunday.setTextColor(Color.parseColor("#434242"));
                    day1_Sunday = "";
                    Sunday_count = 0;

                }

            }
        });

        Monday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Monday_count == 0) {
                    Monday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Monday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day2_Monday = "Monday";
                    Monday_count = 1;

                } else if (Monday_count == 1) {
                    Monday.setBackground(null);
                    Monday.setTextColor(Color.parseColor("#434242"));
                    day2_Monday = "";
                    Monday_count = 0;
                }

            }
        });

        Tuesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Tuesday_count == 0) {
                    Tuesday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Tuesday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day3_Tuesday = "Tuesday";
                    Tuesday_count = 1;

                } else if (Tuesday_count == 1) {
                    Tuesday.setBackground(null);
                    Tuesday.setTextColor(Color.parseColor("#434242"));
                    day3_Tuesday = "";
                    Tuesday_count = 0;

                }

            }
        });


        Wednesday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Wednesday_count == 0) {
                    Wednesday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Wednesday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day4_Wednesday = "Wednesday";
                    Wednesday_count = 1;

                } else if (Wednesday_count == 1) {
                    Wednesday.setBackground(null);
                    Wednesday.setTextColor(Color.parseColor("#434242"));
                    day4_Wednesday = "";
                    Wednesday_count = 0;

                }

            }
        });

        Thursday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Thursday_count == 0) {
                    Thursday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Thursday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day5_Thursday = "Thursday";
                    Thursday_count = 1;

                } else if (Thursday_count == 1) {
                    Thursday.setBackground(null);
                    Thursday.setTextColor(Color.parseColor("#434242"));
                    day5_Thursday = "";
                    Thursday_count = 0;

                }

            }
        });


        Friday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Friday_count == 0) {
                    Friday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Friday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day6_Friday = "Friday";
                    Friday_count = 1;

                } else if (Friday_count == 1) {
                    Friday.setBackground(null);
                    Friday.setTextColor(Color.parseColor("#434242"));
                    day6_Friday = "";
                    Friday_count = 0;

                }

            }
        });

        Saturday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Saturday_count == 0) {
                    Saturday.setBackground(ContextCompat.getDrawable(medicineReminder.this, R.drawable.circle_highlight));
                    Saturday.setTextColor(Color.parseColor("#FFFFFFFF"));
                    day7_Saturday = "Saturday";
                    Saturday_count = 1;

                } else if (Saturday_count == 1) {
                    Saturday.setBackground(null);
                    Saturday.setTextColor(Color.parseColor("#434242"));
                    day7_Saturday = "";
                    Saturday_count = 0;

                }

            }
        });

    }


    private void showTimePicker() {

        medicine_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int start_hour = calendar.get(Calendar.HOUR_OF_DAY);
                int start_minute = calendar.get((Calendar.MINUTE));

                //  boolean Is24hourFormat = DateFormat.is24HourFormat(AppointmentBooking.this);
                TimePickerDialog timePickerDialog = new TimePickerDialog(medicineReminder.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int Hour, int Minute) {

                        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                        int hourOfDay = timePicker.getHour();
                        int minute = timePicker.getMinute();
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);
                        TIME = timeFormat.format(calendar.getTime());
                        medicine_time.setText(TIME);
                    }
                }, start_hour, start_minute, false);
                timePickerDialog.show();

            }

        });

    }




}
