package com.example.docportal.Doctor;

public interface ViewHolder {
}
